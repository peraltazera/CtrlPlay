let menu = document.getElementById("menu")
let select = document.getElementById("numCards")
let start = document.getElementById("start")
let boardDiv = document.getElementById("board")

//Factory
function urlBuilder(number){}

// Object instances
let card = new CardManager(urlBuilder);
let board = new BoardManager("board", 50, card);

for (let i = 4; i <= 10; i+=2){
    let n = i*i;
    let op = document.createElement("option")
    op.value=n
    op.innerHTML=n
    select.appendChild(op)
}

start.addEventListener("click", ()=>{
    menu.classList.add("hidden")
    boardDiv.classList.remove("hidden")
    board.fill(select.value)
})

start.click()


